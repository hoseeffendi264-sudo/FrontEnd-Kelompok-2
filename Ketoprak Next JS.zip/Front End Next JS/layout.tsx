import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Ketoprak Nusantara",
  description: "Ketoprak tradisional dengan bumbu kacang autentik.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id">
      <body>{children}</body>
    </html>
  );
}