import Image from "next/image";

export default function Home() {
return (
<>
<header className="header">
<div className="container header-container">
<h1 className="logo"> Ketoprak Nusantara</h1>
<nav className="nav">
<a href="#beranda">Beranda</a>
<a href="#menu">Menu</a>
<a href="#tentang">Tentang</a>
<a href="#kontak">Kontak</a>
</nav>
</div>
</header>

  <section className="hero" id="beranda">
    <div className="hero-overlay"></div>
    <div className="container hero-content">
      <h2>Cita Rasa Bumbu Kacang Autentik</h2>
      <p>
        Ketoprak tradisional dengan resep turun-temurun, disajikan segar
        dengan lontong pulen, tauge renyah, dan siraman bumbu kacang yang
        gurih.
      </p>
      <a href="#menu" className="btn">
        Lihat Menu Kami
      </a>
    </div>
  </section>

  <section className="menu-section" id="menu">
    <div className="container">
      <h2 className="section-title">Menu Ketoprak</h2>
      <p className="section-subtitle">
        Pilihan ketoprak favorit dengan racikan bumbu spesial
      </p>

      <div className="menu-grid">
        <div className="card">
          <Image
            src="/img/ketoprak-original.jpg"
            alt="Ketoprak Original dengan kerupuk"
            width={400}
            height={220}
          />
          <div className="card-body">
            <h3>Ketoprak Original</h3>
            <p>
              Ketoprak klasik dengan lontong, bihun, tahu, tauge, dan
              kerupuk, disiram bumbu kacang kental yang gurih.
            </p>
            <span className="price">Rp 15.000</span>
          </div>
        </div>

        <div className="card card-jumbo">
          <Image
            src="/img/ketoprak-jumbo.jpg"
            alt="Ketoprak Jumbo porsi besar"
            width={400}
            height={220}
          />
          <div className="card-body">
            <h3>Ketoprak Jumbo</h3>
            <p>
              Porsi super besar untuk kamu yang lapar! Double lontong,
              double tahu, telur, bakso, dan siraman bumbu kacang berlimpah.
            </p>
            <span className="price">Rp 30.000</span>
          </div>
        </div>

        <div className="card">
          <Image
            src="/img/ketoprak-komplit.jpg"
            alt="Ketoprak Komplit dengan tahu dan tauge"
            width={400}
            height={220}
          />
          <div className="card-body">
            <h3>Ketoprak Komplit</h3>
            <p>
              Porsi lebih besar dengan tambahan tahu goreng, tauge
              melimpah, dan taburan bawang goreng renyah.
            </p>
            <span className="price">Rp 20.000</span>
          </div>
        </div>

        <div className="card">
          <Image
            src="/img/ketoprak-telur.jpg"
            alt="Ketoprak Telur dengan timun"
            width={400}
            height={220}
          />
          <div className="card-body">
            <h3>Ketoprak Telur</h3>
            <p>
              Ketoprak spesial dengan telur dadar, irisan timun segar,
              dan bawang goreng di atas piring ayam jago legendaris.
            </p>
            <span className="price">Rp 22.000</span>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section className="menu-section" id="menu">
    <div className="container">
      <h2 className="section-title">Menu Minuman</h2>
      <p className="section-subtitle">
        Pilihan minuman yang mendampingi ketoprak-mu
      </p>

      <div className="menu-grid">
        <div className="card">
          <Image
            src="/img/ketoprak-original.jpg"
            alt="Ketoprak Original dengan kerupuk"
            width={400}
            height={220}
          />
          <div className="card-body">
            <h3>Air mineral</h3>
            <p>Air putih Le Minerale</p>
            <span className="price">Rp 5.000</span>
          </div>
        </div>

        <div className="card card-jumbo">
          <Image
            src="/img/ketoprak-jumbo.jpg"
            alt="Ketoprak Jumbo porsi besar"
            width={400}
            height={220}
          />
          <div className="card-body">
            <h3>Teh panas / dingin</h3>
            <p>
              Teh manis yang diseduh mengunakan pucuk daun yang berkualitas
              bagus
            </p>
            <span className="price">Rp 7.000</span>
          </div>
        </div>

        <div className="card">
          <Image
            src="/img/ketoprak-komplit.jpg"
            alt="Ketoprak Komplit dengan tahu dan tauge"
            width={400}
            height={220}
          />
          <div className="card-body">
            <h3>Kopi nusantara</h3>
            <p>
              Setiap cangkir kopi yang kami sajikan adalah hasil dari
              proses roasting yang cermat dan penyeduhan yang penuh
              perhatian, agar cita rasa asli dari setiap daerah asal kopi
              dapat dinikmati sepenuhnya.
            </p>
            <span className="price">Rp 10.000</span>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section className="drinks-section" id="minuman">
    <div className="container">
      <h2 className="section-title">Menu Minuman</h2>

      <div className="drinks-grid">
        <div className="drink-card">
          <div className="drink-icon"></div>
          <h3>Air Mineral</h3>
          <p>
            Air putih dingin atau suhu ruang untuk menyegarkan tenggorokan.
          </p>
          <span className="price">Rp 4.000</span>
        </div>

        <div className="drink-card">
          <div className="drink-icon"></div>
          <h3>Teh Panas / Es Teh</h3>
          <p>
            Teh tawar hangat atau dingin, cocok untuk Anda yang tidak suka
            manis.
          </p>
          <span className="price">Rp 5.000</span>
        </div>

        <div className="drink-card">
          <div className="drink-icon"></div>
          <h3>Teh Manis</h3>
          <p>
            Teh manis hangat atau es teh manis segar dengan gula asli.
          </p>
          <span className="price">Rp 6.000</span>
        </div>
      </div>
    </div>
  </section>

  <section className="about-section" id="tentang">
    <div className="container">
      <h2 className="section-title">Tentang Kami</h2>
      <div className="about-content">
        <p>
          Ketoprak Nusantara hadir sejak 2010 dengan misi melestarikan
          kuliner tradisional Betawi. Kami menggunakan bahan-bahan segar
          setiap hari dan bumbu kacang yang diulek langsung untuk menjaga
          keaslian rasa.
        </p>
      </div>
    </div>
  </section>

  <footer className="footer" id="kontak">
    <div className="container">
      <p></p>
      <p>
        {" "}Jl. Pluit Sel. No.26-24 4, RT.3/RW.9, Pluit, Kecamatan
        Penjaringan, Jkt Utara, Daerah Khusus Ibukota Jakarta 14450
      </p>
    </div>
  </footer>
</>
);
}